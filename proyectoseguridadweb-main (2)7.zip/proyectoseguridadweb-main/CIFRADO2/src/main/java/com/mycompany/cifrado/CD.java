package com.mycompany.cifrado;

import java.io.*;
import java.util.Scanner;
import javax.swing.JFileChooser;

public class CD {

    private static final byte[] PASSWORD = {'v', 'a', 'l', 'e'}; // "vale"
    
    public static void main(String[] args) {
        try {
            JFileChooser fileChooser = new JFileChooser();
            System.out.println("Seleccione el archivo a procesar...");

            if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                File archivo = fileChooser.getSelectedFile();
                System.out.println("Paso 1: Archivo seleccionado -> " + archivo.getName());

                Scanner scanner = new Scanner(System.in);
                System.out.print("¿Desea cifrar (C) o descifrar (D) el archivo?: ");
                String opcion = scanner.next().toUpperCase();

                if (opcion.equals("C")) {
                    byte[] contenido = leerArchivo(archivo);
                    byte[] resultado = cifrar(contenido);
                    
                    escribirArchivo(resultado, "mensaje_cifrado.txt");

                    System.out.println("Paso 2: Cifrado aplicado con los siguientes pasos:");
                    System.out.println("  • XOR con 'vale'");
                    System.out.println("  • Desplazamiento de bits a la izquierda (<< 3)");
                    System.out.println("  • Multiplicación por 2 (módulo 256)");
                    System.out.println("Paso 3: Archivo guardado como -> mensaje_cifrado.txt");
                    System.out.println("Proceso completado.");
                    
                    System.out.println("Resultado final cifrado:");
                    for (byte b : resultado) {
                        System.out.print((b & 0xFF) + " ");
                    }
                    System.out.println();
                    
                } else if (opcion.equals("D")) {
                    System.out.print("Ingrese los números cifrados separados por espacios: ");
                    scanner.nextLine();  
                    String[] numeros = scanner.nextLine().split(" ");
                    byte[] datosCifrados = new byte[numeros.length];

                    for (int i = 0; i < numeros.length; i++) {
                        datosCifrados[i] = (byte) Integer.parseInt(numeros[i]);
                    }

                    byte[] resultado = descifrar(datosCifrados);
                    escribirArchivo(resultado, "mensaje_descifrado.txt");
                    
                    System.out.println("Paso 2: Descifrado aplicado con los siguientes pasos:");
                    System.out.println("  • División por 2 (módulo 256)");
                    System.out.println("  • Desplazamiento de bits a la derecha (>> 3)");
                    System.out.println("  • XOR con 'vale'");
                    System.out.println("Texto descifrado: " + new String(resultado));
                    System.out.println("Paso 3: Archivo guardado como -> mensaje_descifrado.txt");
                    System.out.println("Proceso completado.");
                } else {
                    System.out.println("Opción no válida.");
                }
            } else {
                System.out.println("No se seleccionó ningún archivo.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static byte[] cifrar(byte[] datos) {
        byte[] cifrado = new byte[datos.length];
        for (int i = 0; i < datos.length; i++) {
            byte paso1 = (byte) (datos[i] ^ PASSWORD[i % PASSWORD.length]); // XOR con "vale"
            byte paso2 = (byte) (paso1 << 3);       // Desplazamiento de bits a la izquierda (<< 3)
            byte paso3 = (byte) ((paso2 * 2) % 256); // Multiplicación por 2 (módulo 256)
            cifrado[i] = paso3;
        }
        return cifrado;
    }

    public static byte[] descifrar(byte[] datos) {
        byte[] descifrado = new byte[datos.length];
        for (int i = 0; i < datos.length; i++) {
            byte paso1 = (byte) ((datos[i] / 2) % 256); // División por 2 (módulo 256)
            byte paso2 = (byte) (paso1 >> 3);          // Desplazamiento de bits a la derecha (>> 3)
            byte paso3 = (byte) (paso2 ^ PASSWORD[i % PASSWORD.length]); // XOR con "vale"
            descifrado[i] = paso3;
        }
        return descifrado;
    }

    public static byte[] leerArchivo(File archivo) throws IOException {
        FileInputStream fis = new FileInputStream(archivo);
        byte[] contenido = fis.readAllBytes();
        fis.close();
        return contenido;
    }

    public static void escribirArchivo(byte[] contenido, String nombreArchivo) throws IOException {
        FileOutputStream fos = new FileOutputStream(nombreArchivo);
        fos.write(contenido);
        fos.close();
        System.out.println("Archivo guardado como: " + nombreArchivo);
    }
}
